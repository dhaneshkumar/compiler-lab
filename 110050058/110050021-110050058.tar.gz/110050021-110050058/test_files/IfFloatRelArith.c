main()
{
	float a = 2.3, b = 3.4, c = 4.5, d = 5.6, e = 6.7;

	if (a >= b + c > d > e * d / c)
		a = a * d / e;
	else
		e = e + d;
}
