main()
{
	int a = 2;
	int b = 4;
	int iftmp0 = 2;

	a? b : iftmp0;
}
