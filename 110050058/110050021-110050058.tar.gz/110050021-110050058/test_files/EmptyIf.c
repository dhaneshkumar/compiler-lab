main()
{
	float f = -1e0, g = +1e1;
	if (f < g);
}
