main()
{
	float a=2.3, b=3.4, c, d;

	d = a+b < a-b < a*b;
}
