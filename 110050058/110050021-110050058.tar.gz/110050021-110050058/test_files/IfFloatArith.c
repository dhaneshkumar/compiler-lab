main()
{
	float a = 2.34, b = 2.1, c = 8.3;

	if (a + b / c / a * b)
		a--;
}
