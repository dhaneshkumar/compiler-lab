main()
{
	int a;
	for(a = 1;;a++)
	{
		if (a > 5)
			return;
	}
}
