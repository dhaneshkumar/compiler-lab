main()
{
	int a = 3, b = 4, c = 5;
	int d = a / (b + c);
	int e = a / b + c;
	int f = (a + b) / c;
	int g = a + (b - c);
	int h = (a + b) * c / ((e - f) > (a - b));
}
