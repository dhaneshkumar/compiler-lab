main()
{
	int a = 2;
	int b = 4, d = 10;

	if (a >= -b)
		a++;
	else
		b++;
}
