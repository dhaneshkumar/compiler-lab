int
Removing;

main()
{
	int a;
}
