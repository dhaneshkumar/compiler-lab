#include <iostream>
using namespace std;

void check()
{
	int i;
}

int main()
{
	check();
	int check=0;
	return 0;
}

