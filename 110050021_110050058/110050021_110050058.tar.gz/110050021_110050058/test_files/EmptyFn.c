main()
{
	fn();
}

fn()
{
}
