float b;
int a;

fn(int c, float d)

{
	int a;
	float b;
	a = c;
	b = d;
}

main()
{
	fn(a, b);
}
