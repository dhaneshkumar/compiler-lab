main()
{
	fn();
}

fn()
{
	return 2;
}
