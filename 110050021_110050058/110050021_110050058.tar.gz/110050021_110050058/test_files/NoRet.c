fn2(int a, int b)
{
   b = 2;
}
main()
{
   int a;
   a = 3;
   fn2(a, a);

}
