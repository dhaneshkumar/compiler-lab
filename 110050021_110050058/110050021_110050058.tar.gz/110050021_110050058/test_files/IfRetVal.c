fn()
{
	int a = 10;
	if (a > 5)
		return 10;
	else
		return a;
}

main()
{
	fn();
}
