main()
{
	int a;
	a = 3;
	fn();
}

int b;

fn()
{
	b = 3;
}
