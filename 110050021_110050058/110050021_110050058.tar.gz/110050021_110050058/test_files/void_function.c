void f(int a)
{

int x=3;
x = x + a;

}

main()
{
int a = 8;
f(a);


}

