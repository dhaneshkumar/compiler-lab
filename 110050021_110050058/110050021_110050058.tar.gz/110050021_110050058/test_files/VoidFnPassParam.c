void fn(int b)
{
	int c;
	c = b;
}

main()
{
	fn(3);
}
