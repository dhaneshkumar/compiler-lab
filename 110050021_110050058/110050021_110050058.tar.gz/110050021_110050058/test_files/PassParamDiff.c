fn(float b, float c)
{
	return b;
}

main()
{
	int a = 10;
	fn (a, 10);
}
