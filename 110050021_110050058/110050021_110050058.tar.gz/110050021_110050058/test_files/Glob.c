int a;
main()
{
	int a = 3;
	a = 10;
	fn();
}

fn()
{
	int a = 6;
}
