int a;
main()
{
	a = 3;
	fn();
	a = 4;
}

fn()
{
	a = 10;
}
