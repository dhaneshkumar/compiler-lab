main()
{
	int a = 10;
	fn(a);
}

fn(int a)
{
	a = 11;
}
