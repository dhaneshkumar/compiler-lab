main()
{
	int a = 3;
	int b = 5;

	fn();
}

fn()
{
	int c = 4;
}
