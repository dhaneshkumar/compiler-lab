main()
{
	int a = 3;
	int b = 2;
	float c = 2.3;

	a = a + c - fn() / b;
}

int fn()
{
	int a = 3;
	return a;
}
