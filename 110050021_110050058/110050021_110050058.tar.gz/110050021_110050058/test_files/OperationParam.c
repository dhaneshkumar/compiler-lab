main()
{
	int a = 10, b =2;
	fn (a + b * a / b <= a + b);
}

fn(int a)
{
	int c = a;
}
