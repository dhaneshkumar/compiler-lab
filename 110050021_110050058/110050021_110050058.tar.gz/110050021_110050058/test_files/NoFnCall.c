main()
{
	int a = 10;
}

fn()
{
	int a = 20;
}
