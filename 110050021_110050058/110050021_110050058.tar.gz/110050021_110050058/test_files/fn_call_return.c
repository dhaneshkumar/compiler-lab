float add(float,float);
main()
{
	float a=2,b=3,c;
	c=add(a,b);

}

float add (float a1,float b1)
{
	return (a1+b1);
}
