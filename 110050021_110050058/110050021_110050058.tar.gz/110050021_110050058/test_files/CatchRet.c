main()
{
	int a;
	a = fn();
}

fn()
{
	return 3;
}
