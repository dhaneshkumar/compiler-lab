main()
{
	int a = 10;
	fn(a);
}

fn(int b)
{
	b = 10;
}
