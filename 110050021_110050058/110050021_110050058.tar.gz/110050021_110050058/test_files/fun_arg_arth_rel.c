float add(float,float);
main()
{
	float a=2,b=3,c=4,d;
	
	
	if(c<=add(a+b,b>1))
		d=add(a,b)+c;

}

float add (float a1,float b1)
{
	return (a1+b1);
}
