int fn();
main()
{
	int a = 10;
	fn();
}

fn()
{
	int e = 10;
}
