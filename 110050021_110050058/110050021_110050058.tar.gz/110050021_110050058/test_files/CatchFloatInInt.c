float fn()
{
	return 2.3;
}

main()
{
	int a;
	a = fn();
}
