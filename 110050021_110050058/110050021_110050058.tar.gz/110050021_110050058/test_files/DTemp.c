main()
{
	int a = 2;
	int D1234 = 3;

	if (a > 5)
		return 10;
	else
		return a;
}
