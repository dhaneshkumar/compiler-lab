void fn()
{
	int b = 2;
}

void main()
{
	int a = 3;
	fn();
}
