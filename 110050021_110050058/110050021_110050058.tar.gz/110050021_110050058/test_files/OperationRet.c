fn(int a, float b, int c, float d)
{
	return a + b - c <= d != a * c;
}

main()
{
	int a = 10;
	a = fn (5 != a < 10, 2.3, a, 3.6);
}
