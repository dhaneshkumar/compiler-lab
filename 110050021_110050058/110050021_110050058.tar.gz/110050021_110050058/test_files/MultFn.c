main()
{
	int a = 10;
	fn1();
	fn2();
}

fn1()
{
	int d = 10;
	fn3();
}

fn2()
{
	int t = 2;
}

fn3()
{
	int y = 0;
}
