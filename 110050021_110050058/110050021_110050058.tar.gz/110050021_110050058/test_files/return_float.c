float sum(float a, float b)
{
float x;
x = a + b;

return x;
}

main()
{
float x,y,z;
x = 8.1;
y = 10.4;

z = sum(x,y);

}
